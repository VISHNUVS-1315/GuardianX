from __future__ import annotations
import asyncio, json, os, secrets, time
from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

app=FastAPI(title='CampusLive API',version='2.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=False,allow_methods=['*'],allow_headers=['*'])
DB=Path(os.getenv('CAMPUSLIVE_DATA','/tmp/campuslive_state.json'))
PASSWORD='Campus@123'
USERS={
 'student@campuslive.demo':{'name':'Vishnu S','role':'student','department':'Mechanical Engineering','year':2,'section':'A','bus':'BUS07'},
 'admin@campuslive.demo':{'name':'Campus Admin','role':'admin','department':'Administration'},
}
TOKENS={}
clients:set[WebSocket]=set()

def now(): return datetime.now().isoformat(timespec='seconds')
def seed():
 return {
  'rooms':[{'id':'M201','block':'Mechanical','status':'available','until':'12:10 PM','capacity':60},{'id':'M202','block':'Mechanical','status':'occupied','until':'','capacity':60},{'id':'M203','block':'Mechanical','status':'available','until':'1:20 PM','capacity':64},{'id':'CAD-LAB','block':'Mechanical','status':'available','until':'2:30 PM','capacity':48}],
  'timetable':[{'start':'09:00','end':'09:50','subject':'Engineering Mechanics','room':'M201','faculty':'Dr. Kumar'},{'start':'10:00','end':'10:50','subject':'Thermodynamics','room':'M203','faculty':'Prof. Ravi'},{'start':'11:30','end':'12:20','subject':'CAD','room':'CAD-LAB','faculty':'Ms. Priya'}],
  'bus':{'id':'BUS07','route':'Udumalpet → Campus','lat':11.001,'lng':77.001,'speed':31,'eta':8,'status':'on_time','updated':now()},
  'placement':{'company':'Zoho','role':'Software Developer','round':'Technical Interview','status':'waiting','queue':7,'registered':340,'aptitude':210,'coding':92,'technical':42,'hr':18,'selected':12},
  'labs':[{'id':'CAD','name':'CAD Lab','total':60,'available':32,'in_use':25,'maintenance':3},{'id':'AI','name':'AI Lab','total':48,'available':21,'in_use':25,'maintenance':2}],
  'announcements':[{'id':1,'title':'Welcome to CampusLive','message':'Campus services are now connected in one live view.','target':'All Students','at':now()}],
  'events':[{'id':1,'title':'TechFest 2026','venue':'Main Auditorium','date':'2026-10-08 10:00','capacity':200,'registered':138,'description':'Coding, robotics and paper presentation.'},{'id':2,'title':'Placement Workshop','venue':'Seminar Hall','date':'2026-10-03 14:00','capacity':120,'registered':76,'description':'Aptitude and interview preparation.'}],
  'registrations':[], 'complaints':[], 'lost':[], 'emergencies':[], 'audit':[]
 }
def load():
 try: return json.loads(DB.read_text())
 except Exception:
  s=seed(); save(s); return s
def save(s):
 DB.parent.mkdir(parents=True,exist_ok=True); DB.write_text(json.dumps(s,separators=(',',':')))
STATE=load()
def audit(who,action):
 STATE['audit'].insert(0,{'who':who,'action':action,'at':now()}); STATE['audit']=STATE['audit'][:100]; save(STATE)
async def push(event='state'):
 dead=[]
 msg=json.dumps({'event':event,'state':STATE,'at':now()})
 for ws in list(clients):
  try: await ws.send_text(msg)
  except Exception: dead.append(ws)
 for ws in dead: clients.discard(ws)
def auth(authorization:str|None):
 if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Sign in required')
 email=TOKENS.get(authorization[7:])
 if not email: raise HTTPException(401,'Session expired')
 return email,USERS[email]
def admin(authorization:str|None):
 email,u=auth(authorization)
 if u['role']!='admin': raise HTTPException(403,'Admin access required')
 return email,u
class Login(BaseModel): email:str; password:str
class RoomIn(BaseModel): status:str; until:str=''
class NoticeIn(BaseModel): title:str=Field(min_length=2,max_length=100); message:str=Field(min_length=2,max_length=400); target:str='All Students'
class BusIn(BaseModel): speed:int=Field(ge=0,le=160); eta:int=Field(ge=0,le=300); status:str='on_time'
class PlacementIn(BaseModel): round:str; status:str; queue:int=Field(ge=0,le=9999)
class LabIn(BaseModel): available:int=Field(ge=0); in_use:int=Field(ge=0); maintenance:int=Field(ge=0)
class ComplaintIn(BaseModel): category:str; location:str; description:str=Field(min_length=5,max_length=400)
class LostIn(BaseModel): kind:str; title:str; description:str; location:str
class EmergencyIn(BaseModel): type:str; location:str
class AskIn(BaseModel): message:str

@app.get('/health')
def health(): return {'ok':True,'service':'CampusLive','version':'2.0','time':now()}
@app.post('/api/login')
def login(x:Login):
 if x.email not in USERS or x.password!=PASSWORD: raise HTTPException(401,'Invalid credentials')
 t=secrets.token_urlsafe(24); TOKENS[t]=x.email; return {'token':t,'user':USERS[x.email]|{'email':x.email}}
@app.get('/api/state')
def state(authorization:str|None=Header(None)):
 email,u=auth(authorization); return {'user':u|{'email':email},'state':STATE}
@app.patch('/api/rooms/{rid}')
async def room(rid:str,x:RoomIn,authorization:str|None=Header(None)):
 email,_=admin(authorization); r=next((z for z in STATE['rooms'] if z['id']==rid),None)
 if not r: raise HTTPException(404,'Room not found')
 if x.status not in {'available','occupied','maintenance'}: raise HTTPException(400,'Invalid status')
 r.update(status=x.status,until=x.until); audit(email,f'room {rid} → {x.status}'); await push('room'); return r
@app.post('/api/announcements')
async def notice(x:NoticeIn,authorization:str|None=Header(None)):
 email,_=admin(authorization); n={'id':int(time.time()*1000),'title':x.title,'message':x.message,'target':x.target,'at':now()}; STATE['announcements'].insert(0,n); audit(email,'published announcement'); await push('announcement'); return n
@app.patch('/api/bus')
async def bus(x:BusIn,authorization:str|None=Header(None)):
 email,_=admin(authorization); STATE['bus'].update(speed=x.speed,eta=x.eta,status=x.status,updated=now()); audit(email,'updated bus'); await push('bus'); return STATE['bus']
@app.patch('/api/placement')
async def placement(x:PlacementIn,authorization:str|None=Header(None)):
 email,_=admin(authorization); STATE['placement'].update(round=x.round,status=x.status,queue=x.queue); audit(email,'updated placement'); await push('placement'); return STATE['placement']
@app.patch('/api/labs/{lid}')
async def lab(lid:str,x:LabIn,authorization:str|None=Header(None)):
 email,_=admin(authorization); l=next((z for z in STATE['labs'] if z['id']==lid),None)
 if not l: raise HTTPException(404,'Lab not found')
 if x.available+x.in_use+x.maintenance!=l['total']: raise HTTPException(400,'Counts must equal total')
 l.update(available=x.available,in_use=x.in_use,maintenance=x.maintenance); audit(email,f'updated lab {lid}'); await push('lab'); return l
@app.post('/api/events/{eid}/register')
async def register(eid:int,authorization:str|None=Header(None)):
 email,u=auth(authorization); e=next((z for z in STATE['events'] if z['id']==eid),None)
 if not e: raise HTTPException(404,'Event not found')
 if any(z['event']==eid and z['email']==email for z in STATE['registrations']): return {'ok':True,'already':True}
 if e['registered']>=e['capacity']: raise HTTPException(409,'Event full')
 code='CL-'+secrets.token_hex(3).upper(); STATE['registrations'].append({'event':eid,'email':email,'code':code}); e['registered']+=1; save(STATE); await push('event'); return {'ok':True,'code':code}
@app.post('/api/complaints')
async def complaint(x:ComplaintIn,authorization:str|None=Header(None)):
 email,u=auth(authorization); c={'id':int(time.time()*1000),'email':email,'category':x.category,'location':x.location,'description':x.description,'status':'reported','at':now()}; STATE['complaints'].insert(0,c); save(STATE); await push('complaint'); return c
@app.patch('/api/complaints/{cid}')
async def complaint_status(cid:int,status:str,authorization:str|None=Header(None)):
 email,_=admin(authorization); c=next((z for z in STATE['complaints'] if z['id']==cid),None)
 if not c: raise HTTPException(404,'Complaint not found')
 if status not in {'reported','assigned','in_progress','resolved'}: raise HTTPException(400,'Invalid status')
 c['status']=status; audit(email,f'complaint {cid} → {status}'); await push('complaint'); return c
@app.post('/api/lost')
async def lost(x:LostIn,authorization:str|None=Header(None)):
 email,u=auth(authorization); d={'id':int(time.time()*1000),'email':email,'kind':x.kind,'title':x.title,'description':x.description,'location':x.location,'status':'open','at':now()}; STATE['lost'].insert(0,d); save(STATE); await push('lost'); return d
@app.post('/api/emergency')
async def emergency(x:EmergencyIn,authorization:str|None=Header(None)):
 email,u=auth(authorization); d={'id':int(time.time()*1000),'email':email,'type':x.type,'location':x.location,'status':'reported','at':now()}; STATE['emergencies'].insert(0,d); save(STATE); await push('emergency'); return d
@app.patch('/api/emergency/{eid}')
async def emergency_ack(eid:int,authorization:str|None=Header(None)):
 email,_=admin(authorization); d=next((z for z in STATE['emergencies'] if z['id']==eid),None)
 if not d: raise HTTPException(404,'Emergency not found')
 d['status']='acknowledged'; d['ack_at']=now(); audit(email,f'acknowledged emergency {eid}'); await push('emergency'); return d
@app.post('/api/ai')
def ai(x:AskIn,authorization:str|None=Header(None)):
 email,u=auth(authorization); q=x.message.lower().strip(); s=STATE
 if 'next' in q and ('class' in q or 'period' in q): z=s['timetable'][0]; a=f"Your next listed class is {z['subject']} at {z['start']} in {z['room']} with {z['faculty']}."
 elif 'bus' in q: b=s['bus']; a=f"{b['id']} is {b['status'].replace('_',' ')} with about {b['eta']} minutes ETA, moving at {b['speed']} km/h."
 elif 'room' in q or 'free' in q: a='Available now: '+', '.join(r['id'] for r in s['rooms'] if r['status']=='available')+'.'
 elif 'placement' in q or 'company' in q: p=s['placement']; a=f"{p['company']} {p['role']} drive is at {p['round']}; your demo queue position is #{p['queue']}."
 elif 'lab' in q: a='; '.join(f"{l['name']}: {l['available']} systems available" for l in s['labs'])+'.'
 elif 'event' in q: a='Upcoming: '+', '.join(e['title'] for e in s['events'])+'.'
 else: a='I can answer live campus questions about classes, rooms, bus ETA, labs, placements and events.'
 return {'answer':a,'source':'CampusLive live context'}
@app.websocket('/ws')
async def ws(websocket:WebSocket):
 await websocket.accept(); clients.add(websocket)
 try:
  while True: await websocket.receive_text()
 except WebSocketDisconnect: clients.discard(websocket)
 except Exception: clients.discard(websocket)

async def bus_sim():
 while True:
  try:
   b=STATE['bus']; b['eta']=max(1,8-int(time.time()/5)%8); b['speed']=28+int(time.time())%10; b['updated']=now(); await push('bus')
  except Exception: pass
  await asyncio.sleep(5)
@app.on_event('startup')
async def startup(): asyncio.create_task(bus_sim())

HTML=r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#143d2c"><title>CampusLive</title><style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f4f7f3;color:#13251d}button,input,select,textarea{font:inherit}button{cursor:pointer}#login{min-height:100vh;display:grid;place-items:center;padding:24px;background:linear-gradient(145deg,#123a2b,#245d43)}.login{width:min(430px,100%);background:#fff;border-radius:24px;padding:26px;box-shadow:0 20px 60px #0005}.brand{font-size:30px;font-weight:900;color:#1b513a}.muted{color:#65756d}.login input,.form input,.form select,.form textarea{width:100%;padding:13px;border:1px solid #d7e1db;border-radius:12px;margin:6px 0 12px;background:#fff}.btn{border:0;border-radius:12px;padding:12px 16px;background:#1d6043;color:white;font-weight:800}.btn.alt{background:#e7efe9;color:#1d6043}.btn.danger{background:#a33535}.row{display:flex;gap:10px;flex-wrap:wrap}.hidden{display:none!important}#app{max-width:1100px;margin:auto;padding:0 14px 80px}.top{position:sticky;top:0;z-index:5;background:#f4f7f3ee;backdrop-filter:blur(10px);padding:14px 0;display:flex;align-items:center;justify-content:space-between}.pill{background:#dff0e5;color:#1d6043;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800}.tabs{display:flex;gap:8px;overflow:auto;padding:6px 0 12px}.tab{white-space:nowrap;border:0;padding:10px 13px;border-radius:12px;background:#e7ece8}.tab.on{background:#1d6043;color:#fff}.view{display:none}.view.on{display:block}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.card{background:#fff;border:1px solid #e1e8e4;border-radius:18px;padding:16px;box-shadow:0 5px 20px #16352510}.card h3,.card h2{margin:5px 0 8px}.label{font-size:11px;font-weight:900;letter-spacing:.12em;color:#6b7e74}.metric{font-size:30px;font-weight:900;color:#1d6043}.status{font-size:12px;font-weight:800;padding:5px 9px;border-radius:999px}.available,.resolved,.acknowledged{background:#ddf3e5;color:#1b6b3e}.occupied,.waiting,.reported{background:#fff0d4;color:#965f00}.maintenance{background:#ffe1e1;color:#9a2b2b}.list{display:grid;gap:10px}.item{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;padding:12px;border-radius:13px;background:#f7faf8}.item small{display:block;color:#6b7e74;margin-top:4px}.form{margin-top:12px}.form textarea{min-height:90px}.ai{display:flex;gap:8px}.ai input{flex:1;padding:12px;border:1px solid #d7e1db;border-radius:12px}.bubble{padding:12px;border-radius:14px;background:#e4f1e9;margin-top:10px}.toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:#15251e;color:#fff;padding:11px 16px;border-radius:12px;z-index:99;max-width:90%;display:none}@media(max-width:600px){.top .brand{font-size:22px}.card{border-radius:15px}.grid{grid-template-columns:1fr 1fr}.wide{grid-column:1/-1}}
</style></head><body><section id="login"><div class="login"><div class="brand">CampusLive</div><p class="muted">Real-Time College Operating System</p><label>Email<input id="email" type="email"></label><label>Password<input id="pass" type="password" value="Campus@123"></label><button class="btn" style="width:100%" onclick="login()">Sign in</button><p id="err" style="color:#a22"></p><div class="row"><button class="btn alt" onclick="demo('student')">Student demo</button><button class="btn alt" onclick="demo('admin')">Admin demo</button></div></div></section><main id="app" class="hidden"><header class="top"><div><div class="brand">CampusLive</div><small id="who"></small></div><div class="row"><span id="live" class="pill">LIVE</span><button class="btn alt" onclick="logout()">Logout</button></div></header><nav class="tabs" id="tabs"></nav><section id="views"></section></main><div id="toast" class="toast"></div><script>
const $=id=>document.getElementById(id),mode=new URLSearchParams(location.search).get('mode')||'student';let token=localStorage.cltoken||'',user=null,S=null,ws=null;const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));$('email').value=mode==='admin'?'admin@campuslive.demo':'student@campuslive.demo';function toast(x){$('toast').textContent=x;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',2400)}async function api(path,opt={}){opt.headers={...(opt.headers||{}),'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})};let r=await fetch(path,opt);let j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.detail||'Request failed');return j}async function login(){try{let d=await api('/api/login',{method:'POST',body:JSON.stringify({email:$('email').value,password:$('pass').value})});token=d.token;localStorage.cltoken=token;await boot()}catch(e){$('err').textContent=e.message}}function demo(r){$('email').value=r+'@campuslive.demo';$('pass').value='Campus@123';login()}function logout(){localStorage.removeItem('cltoken');location.reload()}async function boot(){try{let d=await api('/api/state');user=d.user;S=d.state;$('login').classList.add('hidden');$('app').classList.remove('hidden');$('who').textContent=user.name+' · '+user.role;render();connect()}catch(e){token='';localStorage.removeItem('cltoken')}}
function tabs(){let a=[['home','Home'],['classes','Classes'],['transport','Bus'],['placement','Placement'],['events','Events'],['services','Services'],['ai','Campus AI']];if(user.role==='admin')a.push(['admin','Admin']);$('tabs').innerHTML=a.map((x,i)=>`<button class="tab ${i?'':'on'}" onclick="show('${x[0]}',this)">${x[1]}</button>`).join('');$('views').innerHTML=a.map((x,i)=>`<div id="v-${x[0]}" class="view ${i?'':'on'}"></div>`).join('')}function show(v,b){document.querySelectorAll('.view').forEach(x=>x.classList.remove('on'));$('v-'+v).classList.add('on');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));b.classList.add('on')}
function status(x){return `<span class="status ${esc(x)}">${esc(x).replaceAll('_',' ')}</span>`}function render(){tabs();let b=S.bus,p=S.placement;$('v-home').innerHTML=`<div class="grid"><div class="card"><div class="label">NEXT CLASS</div><h3>${esc(S.timetable[0].subject)}</h3><p>${esc(S.timetable[0].start)} · ${esc(S.timetable[0].room)}</p></div><div class="card"><div class="label">MY BUS</div><div class="metric">${b.eta} min</div><p>${esc(b.id)} · ${b.speed} km/h</p></div><div class="card"><div class="label">PLACEMENT</div><h3>${esc(p.company)}</h3><p>${esc(p.round)} · Queue #${p.queue}</p></div><div class="card"><div class="label">LABS</div><div class="metric">${S.labs.reduce((a,x)=>a+x.available,0)}</div><p>systems available</p></div></div><div class="card" style="margin-top:12px"><div class="label">LIVE ROOMS</div><div class="list">${S.rooms.map(r=>`<div class="item"><div><b>${esc(r.id)}</b><small>${esc(r.block)} · ${r.capacity} seats</small></div>${status(r.status)}</div>`).join('')}</div></div><div class="card" style="margin-top:12px"><div class="label">ANNOUNCEMENTS</div><div class="list">${S.announcements.slice(0,6).map(n=>`<div class="item"><div><b>${esc(n.title)}</b><small>${esc(n.message)} · ${esc(n.target)}</small></div></div>`).join('')}</div></div>`;
$('v-classes').innerHTML=`<div class="card"><h2>Today's timetable</h2><div class="list">${S.timetable.map(x=>`<div class="item"><div><b>${esc(x.subject)}</b><small>${x.start}–${x.end} · ${esc(x.faculty)}</small></div><b>${esc(x.room)}</b></div>`).join('')}</div></div><div class="card" style="margin-top:12px"><h2>Labs</h2><div class="list">${S.labs.map(l=>`<div class="item"><div><b>${esc(l.name)}</b><small>${l.in_use} in use · ${l.maintenance} maintenance</small></div><div class="metric">${l.available}</div></div>`).join('')}</div></div>`;
$('v-transport').innerHTML=`<div class="card"><div class="label">LIVE TRANSPORT</div><h2>${esc(b.id)}</h2><p>${esc(b.route)}</p><div class="grid"><div><div class="metric">${b.eta}</div><small>minutes ETA</small></div><div><div class="metric">${b.speed}</div><small>km/h</small></div></div><p>${status(b.status)} <small>Updated ${esc(b.updated)}</small></p></div>`;
$('v-placement').innerHTML=`<div class="card"><div class="label">PLACEMENT LIVE</div><h2>${esc(p.company)}</h2><p>${esc(p.role)}</p><h3>${esc(p.round)}</h3><p>${status(p.status)} · Queue #${p.queue}</p><div class="grid">${['registered','aptitude','coding','technical','hr','selected'].map(k=>`<div class="item"><div><small>${k}</small><b>${p[k]}</b></div></div>`).join('')}</div></div>`;
$('v-events').innerHTML=`<div class="grid">${S.events.map(e=>`<div class="card"><div class="label">${esc(e.date)}</div><h3>${esc(e.title)}</h3><p>${esc(e.description)}</p><small>${esc(e.venue)} · ${e.registered}/${e.capacity}</small>${user.role==='student'?`<p><button class="btn" onclick="reg(${e.id})">Register</button></p>`:''}</div>`).join('')}</div>`;
$('v-services').innerHTML=`<div class="grid"><div class="card wide"><h3>Report campus issue</h3><div class="form"><select id="ccat"><option>Electrical</option><option>IT</option><option>Classroom</option><option>Transport</option><option>Other</option></select><input id="cloc" placeholder="Location"><textarea id="cdesc" placeholder="Describe the issue"></textarea><button class="btn" onclick="complaint()">Submit complaint</button></div></div><div class="card"><h3>Lost & Found</h3><div class="form"><select id="lkind"><option>lost</option><option>found</option></select><input id="ltitle" placeholder="Item"><input id="lloc" placeholder="Location"><textarea id="ldesc" placeholder="Description"></textarea><button class="btn" onclick="lost()">Post</button></div></div><div class="card"><h3>Emergency</h3><p class="muted">Sends a campus emergency request to admin.</p><div class="form"><select id="etype"><option>Medical</option><option>Fire</option><option>Security</option><option>Accident</option><option>Other</option></select><input id="eloc" placeholder="Location"><button class="btn danger" onclick="emergency()">Send emergency</button></div></div></div><div class="card" style="margin-top:12px"><h3>Complaint status</h3><div class="list">${S.complaints.filter(c=>user.role==='admin'||c.email===user.email).map(c=>`<div class="item"><div><b>${esc(c.category)} · ${esc(c.location)}</b><small>${esc(c.description)}</small></div>${status(c.status)}</div>`).join('')||'<p class="muted">No reports yet.</p>'}</div></div>`;
$('v-ai').innerHTML=`<div class="card"><div class="label">CAMPUS AI</div><h2>Ask live campus questions</h2><p class="muted">Answers from current CampusLive data, not generic guesses.</p><div class="ai"><input id="ask" placeholder="Where is my next class?"><button class="btn" onclick="ask()">Ask</button></div><div id="ans"></div></div>`;if(user.role==='admin')adminView()}
function adminView(){let p=S.placement;$('v-admin').innerHTML=`<div class="grid"><div class="card"><h3>Publish announcement</h3><div class="form"><input id="nt" placeholder="Title"><input id="ntr" value="All Students"><textarea id="nm" placeholder="Message"></textarea><button class="btn" onclick="notice()">Publish live</button></div></div><div class="card"><h3>Update room</h3><div class="form"><select id="rid">${S.rooms.map(r=>`<option>${r.id}</option>`).join('')}</select><select id="rst"><option>available</option><option>occupied</option><option>maintenance</option></select><input id="runtil" placeholder="Available until"><button class="btn" onclick="room()">Update live</button></div></div><div class="card"><h3>Transport control</h3><div class="form"><input id="bs" type="number" value="${S.bus.speed}"><input id="be" type="number" value="${S.bus.eta}"><select id="bst"><option>on_time</option><option>delayed</option><option>arrived</option></select><button class="btn" onclick="bus()">Push bus update</button></div></div><div class="card"><h3>Placement control</h3><div class="form"><input id="pr" value="${esc(p.round)}"><select id="ps"><option>waiting</option><option>in_progress</option><option>completed</option><option>upcoming</option></select><input id="pq" type="number" value="${p.queue}"><button class="btn" onclick="place()">Update placement</button></div></div></div><div class="card" style="margin-top:12px"><h3>Emergency desk</h3><div class="list">${S.emergencies.map(e=>`<div class="item"><div><b>${esc(e.type)} · ${esc(e.location)}</b><small>${esc(e.email)} · ${esc(e.at)}</small></div>${e.status==='reported'?`<button class="btn danger" onclick="ack(${e.id})">Acknowledge</button>`:status(e.status)}</div>`).join('')||'<p class="muted">No emergencies.</p>'}</div></div><div class="card" style="margin-top:12px"><h3>Complaints</h3><div class="list">${S.complaints.map(c=>`<div class="item"><div><b>${esc(c.category)} · ${esc(c.location)}</b><small>${esc(c.description)}</small></div><div>${status(c.status)} ${c.status!=='resolved'?`<button class="btn alt" onclick="resolveC(${c.id})">Resolve</button>`:''}</div></div>`).join('')||'<p class="muted">No complaints.</p>'}</div></div>`}
async function post(path,obj,method='POST'){try{let d=await api(path,{method,body:JSON.stringify(obj)});toast('Updated');if(d.state)S=d.state;else{let x=await api('/api/state');S=x.state}render()}catch(e){toast(e.message)}}async function reg(id){try{let d=await api('/api/events/'+id+'/register',{method:'POST'});toast(d.already?'Already registered':'Pass: '+d.code);let x=await api('/api/state');S=x.state;render()}catch(e){toast(e.message)}}function complaint(){post('/api/complaints',{category:$('ccat').value,location:$('cloc').value,description:$('cdesc').value})}function lost(){post('/api/lost',{kind:$('lkind').value,title:$('ltitle').value,location:$('lloc').value,description:$('ldesc').value})}function emergency(){post('/api/emergency',{type:$('etype').value,location:$('eloc').value})}function notice(){post('/api/announcements',{title:$('nt').value,target:$('ntr').value,message:$('nm').value})}function room(){post('/api/rooms/'+$('rid').value,{status:$('rst').value,until:$('runtil').value},'PATCH')}function bus(){post('/api/bus',{speed:+$('bs').value,eta:+$('be').value,status:$('bst').value},'PATCH')}function place(){post('/api/placement',{round:$('pr').value,status:$('ps').value,queue:+$('pq').value},'PATCH')}function ack(id){post('/api/emergency/'+id,{},'PATCH')}async function resolveC(id){try{await api('/api/complaints/'+id+'?status=resolved',{method:'PATCH'});toast('Resolved');let x=await api('/api/state');S=x.state;render()}catch(e){toast(e.message)}}async function ask(){try{let d=await api('/api/ai',{method:'POST',body:JSON.stringify({message:$('ask').value})});$('ans').innerHTML=`<div class="bubble">${esc(d.answer)}<small style="display:block;margin-top:6px">${esc(d.source)}</small></div>`}catch(e){toast(e.message)}}function connect(){try{ws=new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.host+'/ws');ws.onopen=()=>{$('live').textContent='LIVE';$('live').style.opacity=1};ws.onclose=()=>{if($('live')){$('live').textContent='RECONNECTING';$('live').style.opacity=.6}setTimeout(connect,2000)};ws.onmessage=async()=>{try{let x=await api('/api/state');S=x.state;render()}catch(e){}}}catch(e){setTimeout(connect,3000)}}if(token)boot();
</script></body></html>'''
@app.get('/',response_class=HTMLResponse)
def root(): return HTML
